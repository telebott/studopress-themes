# Kreativ Pro WordPress Theme

Theme link: http://themesquare.com/themes/kreativ/

## Installation

1. Make sure you have already installed and activated the Genesis Framework (This is the parent theme).
2. Go to your WordPress dashboard and select Appearance > Themes.
3. Click on Add New link to upload the Kreativ Pro theme and activate it.
4. Alternatively, you can also upload Kreativ Pro theme folder via FPT to your wp-content/themes/ directory.
5. Upon activation, you can configure theme options on Genesis > Theme Options page.
